package com.cg.empSystem.tests;



import static org.junit.Assert.*;

import java.sql.SQLException;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import com.cg.empSystem.dao.EmployeeDao;
import com.cg.empSystem.dao.EmployeeDaoImpl;
import com.cg.empSystem.dto.Employee;
import com.cg.empSystem.exception.EmployeeException;

public class TestRemoveEmployeeDetails {

	EmployeeDao dao;
	Employee employee;
	
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	
	dao = new EmployeeDaoImpl();
	employee= new Employee();
	}

	@After
	public void tearDown() throws Exception {
	dao= null;
	employee= null;
	
	}

	@Test
	public void testRemoveEmployeeDetails() throws EmployeeException, SQLException {
		assertTrue(dao.removeEmployeeDetails("100001"));
	}

}
