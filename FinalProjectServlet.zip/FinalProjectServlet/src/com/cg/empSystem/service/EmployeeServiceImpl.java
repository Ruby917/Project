package com.cg.empSystem.service;


import java.sql.SQLException;
import java.util.List;

import com.cg.empSystem.dao.EmployeeDao;
import com.cg.empSystem.dao.EmployeeDaoImpl;
import com.cg.empSystem.dto.Employee;
import com.cg.empSystem.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService{
	EmployeeDao empDao = null;
	public EmployeeServiceImpl() throws EmployeeException {
		empDao = new EmployeeDaoImpl();
	}
	//Start Of Add Employee
	@Override
	public String addEmployeeDetails(Employee emp) throws EmployeeException {
		try {
			String empId=empDao.addEmployeeDetails(emp);
			return empId;
		} catch (EmployeeException e) {
			
			System.out.println(e.getMessage());
			throw new EmployeeException(e.getMessage());
		}
		
	}// End Of Add Employee
	
	// Start of Remove Employee
	@Override
	public boolean removeEmployeeDetails(String empId) throws EmployeeException, SQLException {
		try {
			 return empDao.removeEmployeeDetails(empId);
		
		}  catch (EmployeeException e) {
			
			System.out.println(e.getMessage());
			throw new EmployeeException(e.getMessage());
		}
	}//End Of Remove Employee
	
	//Start Of Show All
	@Override
	public List<Employee> showAll() throws EmployeeException, SQLException {
		try {
			List<Employee> empList=empDao.showAll();
			return empList;
		}  catch (EmployeeException e) {
			
			System.out.println(e.getMessage());
			throw new EmployeeException(e.getMessage());
		}
	}//End Of Show All
	
	//Start Of Valid Login
	@Override
	public int isValid(String userName, String userPassword)
			throws EmployeeException {
		try {
			int data=empDao.isValid(userName, userPassword);
			return data;
		}  catch (EmployeeException e) {
			
			System.out.println(e.getMessage());
			throw new EmployeeException(e.getMessage());
		}
	}//End Of Valid login
	
	//Start Of Search Employee On Id
	@Override
	public Employee searchEmployeeOnId(String EmpId) throws EmployeeException {
		try {
			Employee emp=empDao.searchEmployeeOnId(EmpId);
			return emp;
		}  catch (EmployeeException e) {
			
			System.out.println(e.getMessage());
			throw new EmployeeException(e.getMessage());
		}
	
	}//End of Search Employee On Id
	
	//Start of Search Employee on First name
	@Override
	public List<Employee> searchEmployeeOnFirstName(String firstName)
			throws EmployeeException {
		try {
			List<Employee> empFirstNameList=empDao.searchEmployeeOnFirstName(firstName);
			return empFirstNameList;
		}  catch (EmployeeException e) {
			
			System.out.println(e.getMessage());
			throw new EmployeeException(e.getMessage());
		}
	}//End of Search Employee on First name
	
	//Start of Search Employee on Last name
	@Override
	public List<Employee> searchEmployeeOnLastName(String lastName)
			throws EmployeeException {
		try {
			List<Employee> empLastNameList=empDao.searchEmployeeOnLastName(lastName);
			return empLastNameList;
		} catch (EmployeeException e) {
			
			System.out.println(e.getMessage());
			throw new EmployeeException(e.getMessage());
		}
	}//End of Search Employee on last name
	
	//Start Of Search Employee on Department name
	@Override
	public List<Employee> searchEmployeeOnDepartment(String empDept1,
			String empDept2, String empDept3, String empDept4, String empDept5,
			String empDept6) throws EmployeeException {
		
		try {
			return empDao.searchEmployeeOnDepartment(empDept1, empDept2, empDept3, empDept4, empDept5, empDept6);
		} catch (EmployeeException e) {
			
			System.out.println(e.getMessage());
			throw new EmployeeException(e.getMessage());
		}
	}
	//End Of Search Employee on Department name
	
	//Start of Search Employee on Grade
	@Override
	public List<Employee> searchEmployeeOnGrade(String grade1, String grade2,
			String grade3, String grade4, String grade5, String grade6,
			String grade7) throws EmployeeException {
		
		try {
			return empDao.searchEmployeeOnGrade(grade1, grade2, grade3, grade4, grade5, grade6, grade7);
		} catch (EmployeeException e) {
			
			System.out.println(e.getMessage());
			throw new EmployeeException(e.getMessage());
		}
	}
	//End of Search Employee on Grade
	
	//Start of Search Employee on Marital Status
	@Override
	public List<Employee> searchEmployeeOnMaritalStatus(String status1, String status2, String status3, String status4, String status5)
			throws EmployeeException {
		try {
			List<Employee> empMaritalList=empDao.searchEmployeeOnMaritalStatus(status1, status2, status3, status4, status5);
			return empMaritalList;
		} catch (EmployeeException e) {
			
			System.out.println(e.getMessage());
			throw new EmployeeException(e.getMessage());
		}
	}//End Of Search Employee on Marital Status
	
	
	//Start of update employee
	@Override
	public Employee updateEmployee(Employee emp) throws EmployeeException {
		try {
			Employee employee=empDao.updateEmployee(emp);
			
			return employee;
		} catch (EmployeeException e) {
			
			System.out.println(e.getMessage());
			throw new EmployeeException(e.getMessage());
		}
	}//End of update employee
	
	
	

	
}
